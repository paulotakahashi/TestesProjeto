var titulo = document.querySelector(".titulo");
titulo.textContent = "Aparecida Nutricionista";

var paciente = document.querySelectorAll(".paciente");

for(var i = 0; i < paciente.length; i++) {
    var tdPeso = paciente[i].querySelector(".info-peso");
    var peso = tdPeso.textContent;

    var tdAltura = paciente[i].querySelector(".info-altura");
    var altura = tdAltura.textContent;

    var tdImc = paciente[i].querySelector(".info-imc");

    if(pesoOK(peso)) {
      if(alturaOK(altura)) {
        tdImc.textContent = calculaIMC(peso, altura);
      } else {
        tdImc.textContent = "Altura inválida!";
        paciente[i].classList.add("paciente-invalido");
      }
    } else {
      tdImc.textContent = "Peso inválido";
      paciente[i].classList.add("paciente-invalido");
    }
}

function calculaIMC(peso, altura) {
  var imc = 0;

  imc = peso / (altura * altura);

  return imc.toFixed(2);
}

function pesoOK(peso) {
  var pesoMinimo =  0;
  var pesoMaximo = 500;
  if(peso > pesoMinimo && peso < pesoMaximo) {
    return true;
  } else {
    return false;
  }
}

function alturaOK(altura) {
  var alturaMinima = 0;
  var alturaMaxima = 3;
 if(altura > alturaMinima && altura < alturaMaxima) {
   return true;
 } else {
   return false;
 }
}
